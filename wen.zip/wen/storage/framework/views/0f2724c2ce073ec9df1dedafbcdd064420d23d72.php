<?php $__env->startSection('pageTitle', 'Blog'); ?>
<?php $__env->startSection('content'); ?>

    <section class="inner-header divider parallax layer-overlay overlay-dark-5">
      <div class="container">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">Blog</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="row multi-row-clearfix">
          <div class="blog-posts">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>      
            <div class="col-md-4">
              <article class="post clearfix mb-30 bg-lighter">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="<?php echo e(asset('storage')); ?>/<?php echo e($post->featured_image); ?>" alt="<?php echo e($post->title); ?>" class="img-responsive img-fullwidth" style="height:250px"> 
                  </div>
                </div>
                <div class="entry-content p-20 pr-10">
                  <div class="entry-meta media mt-0 no-bg no-border">
                   
                    <div class="media-body pl-15">
                      <div class="event-content pull-left flip">
                        <h4 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo e(url('/')); ?>/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h4>
                        <span class="mb-10 text-gray-darkgray mr-10 font-13"><i class="fa fa-commenting-o mr-5 text-theme-colored"></i> 214 Comments</span>                       
                      </div>
                    </div>
                  </div>
                  <p class="mt-10"><?php echo e(substr(strip_tags($post->description) , 0, 120)); ?></p>
                  <a href="<?php echo e(url('/')); ?>/<?php echo e($post->slug); ?>" class="btn-read-more">Read more</a>
                  <div class="clearfix"></div>
                </div>
              </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <h2>Nothing news found, check back later</h2>
            <?php endif; ?>
            <div class="col-md-12">
              <nav>
                <ul class="pagination theme-colored">
                  <?php echo e($posts->links()); ?>

                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>