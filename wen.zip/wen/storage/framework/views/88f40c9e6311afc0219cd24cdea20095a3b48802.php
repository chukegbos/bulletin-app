<?php $__env->startSection('pageTitle', 'All Events'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
   <section class="content">
      <div class="row">
        
        <div class="col-md-12">
          
          <div class="box">
            <div class="box-header" style="text-align:center">
              <h3 class="box-title">All Events & Conferences</h3>
            </div><!-- /.box-header -->

            <div class="box-body">
              <div class="table-responsive">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                      <tr>
                        <th>Title</th>
                        <th>Venue</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Delete</th>

                      </tr>
                    </thead>
                  <tbody>

                  <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td>
                        <?php echo e($event->title); ?> <br>
                        <a target="_blank" class="btn btn-primary btn-sm" href="<?php echo e(url('/event')); ?>/?slug=<?php echo e($event->slug); ?>">View</a> 
                        <a href="<?php echo e(url('admin/editevent')); ?>/?slug=<?php echo e($event->slug); ?>"><i class="fa fa-edit btn btn-info btn-sm">Edit</i></a></td>
                      </td>
                      <td><?php echo e($event->venue); ?></td>
                      <td><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->date_event))->toFormattedDateString()); ?><br><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->date_event))->diffForHumans()); ?></td>
                      <td><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->end_event))->toFormattedDateString()); ?><br><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->end_event))->diffForHumans()); ?></td>
                      <td>
                        <form action="<?php echo e(url('/admin/deleteevent')); ?>/<?php echo e($event->id); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(Method_field('DELETE')); ?>

                          <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <?php endif; ?>
                </table>
              </div>
            </div>
          </div><!-- /.box -->
        </div>
      </div>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>