<?php $__env->startSection('pageTitle', 'Photo Speaks'); ?>
<?php $__env->startSection('content'); ?>

    <section class="inner-header divider parallax layer-overlay overlay-dark-5">
      <div class="container">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">Photo Speaks</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container pb-20">
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
            
              <!-- Portfolio Gallery Grid -->
              <div id="grid" class="gallery-isotope grid-3 gutter clearfix">
                <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <!-- Portfolio Item Start -->
                  <div class="gallery-item photography">
                    <div class="thumb">
                      <img class="img-fullwidth" src="<?php echo e(asset('storage')); ?>/<?php echo e($gallery->image); ?>" alt="<?php echo e($gallery->name); ?>" style="height:250px">
                      <div class="overlay-shade"></div>
                      <div class="icons-holder">
                        <div class="icons-holder-inner">
                          <div class="styled-icons icon-sm icon-dark icon-circled icon-theme-colored">
                            <a data-lightbox="image" href="<?php echo e(asset('storage')); ?>/<?php echo e($gallery->image); ?>"><i class="fa fa-plus"></i></a>
                          </div>
                        </div>
                      </div>
                      <a class="hover-link" data-lightbox="image" href="<?php echo e(asset('storage')); ?>/<?php echo e($gallery->image); ?>">View</a>
                    </div>
                    <h5 class="text-center mt-15 mb-40"><?php echo e($gallery->name); ?></h5>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
              </div>
              <!-- End Portfolio Gallery Grid -->
              <div class="row gallery-bottom">
                  <div class="col-sm-6">
                      <ul class="pagination">
                          <?php echo e($galleries->links()); ?>

                      </ul>
                  </div>
              </div>         
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>