<?php $__env->startSection('pageTitle', 'About Us'); ?>
<?php $__env->startSection('content'); ?>
 <div class="breadcrumb-wrap">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h4>About Our Bank</h4>
            </div>

        </div>
    </div>
</div>

<div class="divide80"></div>
<div class="container">
    <div class="row">
        <div class="col-md-7 margin20">
            <h3 class="heading">Who We Are</h3>
            <p style="text-align:justify"><?php echo e($setting->about); ?></p>
        </div>
        <div class="col-md-5 margin20">
            <h3 class="heading">What we stand for</h3>
            <div class="panel-group" id="accordion">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                 <img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN"> Our Vision
                            </a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in">
                        <div class="panel-body">
                           <p style="text-align:justify"> <?php echo e($setting->vision); ?> <p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                 <img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN"> Our Vision
                            </a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse">
                        <div class="panel-body">
                            <p style="text-align:justify"> <?php echo e($setting->mission); ?> <p>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
    </div><!--about intro-->
</div><!--.container-->

<div class="divide80"></div>
<div class="container">
    <div class="row">
         <div class="col-md-6 margin20">
            <h3 class="heading">Open an account with us and enjoy:</h3>
            <div class="skills-wrapper wow animated bounceIn animated" data-wow-delay="0.2s">
                <ul class="services-me list-unstyled">
                    <li><img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN"> Low minimum opening balance.</li>
                    <li><img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN"> Account can be opened at anytime within the working hour.</li>
                    <li><img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN"> Easy access to your account.</li>
                    <li><img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN"> Payments can be made anywhere through our corresponding banks.</li>
                    <li><img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN"> You are able to secure and grow savings.</li>
                    <li><img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN"> Available to individuals and groups.</li>
                </ul>
            </div><!--skills-->
        </div><!--col-->

        <div class="col-md-6 margin20">
            <h3 class="heading">We are good at</h3>
            <div class="skills-wrapper wow animated bounceIn animated" data-wow-delay="0.2s">
                <h3 class="heading-progress">Project Financing  <span class="pull-right">88%</span></h3>
                <div class="progress">
                    <div class="progress-bar" style="width: 88%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="88" role="progressbar">
                    </div>
                </div>
                <h3 class="heading-progress">Consumer/General Loan  <span class="pull-right">78%</span></h3>
                <div class="progress">
                    <div class="progress-bar" style="width: 78%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="78" role="progressbar">
                    </div>
                </div>
                <h3 class="heading-progress">Overdraft  <span class="pull-right">82%</span></h3>
                <div class="progress">
                    <div class="progress-bar" style="width: 82%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="82" role="progressbar">
                    </div>
                </div>   
                <h3 class="heading-progress">Salary Advance  <span class="pull-right">72%</span></h3>
                <div class="progress">
                    <div class="progress-bar" style="width: 72%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="72" role="progressbar">
                    </div>
                </div>

                <h3 class="heading-progress">Agric Loan   <span class="pull-right">78%</span></h3>
                <div class="progress">
                    <div class="progress-bar" style="width: 78%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="78" role="progressbar">
                    </div>
                </div> 

                <h3 class="heading-progress">Group Loan   <span class="pull-right">82%</span></h3>
                <div class="progress">
                    <div class="progress-bar" style="width: 82%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="82" role="progressbar">
                    </div>
                </div>   
                <h3 class="heading-progress">Trade Finance  <span class="pull-right">72%</span></h3>
                <div class="progress">
                    <div class="progress-bar" style="width: 72%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="72" role="progressbar">
                    </div>
                </div>
            </div><!--skills-->
        </div><!--col-->
    </div><!--about intro-->
</div><!--.container-->


<div class="divide60"></div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="center-heading">
                <h2>Mangement Team</h2>
                <span class="center-line"></span>
            </div><!--center-heading-->
        </div>
    </div>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $management1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $management): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 margin20">
                <div class="team-wrap">
                    <?php if(isset($management->image)): ?>
                        <img class="img-responsive"src="<?php echo e(asset('storage')); ?>/<?php echo e($management->image); ?>" style="height:200px; width:300px">
                    <?php else: ?>
                        <img class="img-responsive" src="<?php echo e(asset('live/images/avatar.png')); ?>" style="height:200px; width:300px">
                    <?php endif; ?>
                    <img src="img/team-1.jpg" class="img-responsive" alt="">
                    <h4><?php echo e($management->name); ?></h4>
                    <span><?php echo e($management->post); ?></span>
                </div><!--team-wrap-->
            </div><!--team col-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>               
    </div><!--features-box container end-->
</div><!--team-->

<div class="divide60"></div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>