<?php $__env->startSection('pageTitle', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <section class="sabbbi-section home-info mt_35">
        <div class="container">
            <div class="row home-info-block-first">
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <div class="col-md-3 col-sm-6">
                        <article class="sabbi-thumlinepost-card solitude-bg__x">
                            <figure class="sabbi-thumlinepost-card-figure">
                                <?php if(isset($post->video)): ?>
                                    <a class="video-play" href="<?php echo e($post->video); ?>" data-toggle="lightbox">
                                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($post->featured_image); ?>" alt="" class="img-responsive img-thumpost">
                                    </a>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('storage')); ?>/<?php echo e($post->featured_image); ?>" alt="" class="img-responsive img-thumpost" style="height: 250px">
                                <?php endif; ?>
                            </figure>
                            <div class="sabbi-thumlinepost-card-meta">
                                <h2 class="meta-title ht-5"><?php echo e($post->title); ?></h2>
                                <p class="meta-text"><?php echo e(substr(strip_tags($post->description) , 0, 100)); ?> ...</p>
                                <a href="<?php echo e(url('/')); ?>/<?php echo e($post->slug); ?>" class="btn btn-info btn-xs pull-left">Read More</a> 
                                <a href="<?php echo e(asset('storage')); ?>/<?php echo e($post->pdf); ?>" class="btn btn-success btn-xs pull-right">Download PDF</a>
                            </div>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?> 
            </div>
            <!--<div class="row mt_30">
                <div class="col-sm-4">
                    <article class="sabbi-thumlinepost-card solitude-bg__x">
                        <h2 class="entry-title ht-4">About Research Group</h2>
                        <div class="sabbi-thumlinepost-card-meta">
                            <p class="entry-text">Lorem ipsum dolor sit amet, con adipiscing elit. Etiam convallis elit id impedie. Quisq commodo ornare tortor Quiue bibendum. magna vitae ex interdum cursus. Nullam lacinia pretium nibh, vitae imperdiet lacus tempor sit amet. Donec ultrices est nec tellus finibus facilisis. Nullam sodales justo id magna fringilla rutrum. Duis bibendum id eros congue bibendum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam convallis elit</p>
                            <a href="#" class="btn btn-unsolemn btn-action read-more">Read More</a>
                        </div>
                    </article>
                </div>
                <div class="col-sm-4">
                    <article class="sabbi-thumlinepost-card card-video solitude-bg__x">
                        <figure class="sabbi-thumlinepost-card-figure">
                            <a class="video-play"  href="https://www.youtube.com/watch?v=qarc7AA4-wM" data-toggle="lightbox"><img src="<?php echo e(asset('assets/img/sabbi-post/card-img-5.jpg')); ?>" alt="" class="img-responsive img-thumpost"></a>
                            <figcaption>DR.Rushmore  Remarkable Journey</figcaption>
                        </figure>
                        <h3 class="entry-title"><a href="#">DR.Rushmore  Remarkable Journey</a></h3>
                        <p class="entry-text">Lorem ipsum dolor sit amet, con adipiscing elit. Etiam convallis elit id impedie. Quisq commodo ornare tortor Quiue bibendum.</p>
                    </article>
                </div>
                <div class="col-sm-4">
                    <article class="news-card sabbi-thumlinepost-card solitude-bg__x">
                        <h2 class="stage-title">Latest Events</h2>
                        <ul class="list-unstyled lst_news_list" tabindex="0">
                            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                <li class="lst_news_item">
                                    <h3 class="title mg_0"><a href="events_single.html"><?php echo e($event->title); ?></a></h3>
                                    <div>
                                        <span class="date"><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->date_event))->toFormattedDateString()); ?> - <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->end_event))->toFormattedDateString()); ?></span>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?> 
                        </ul>
                        <a href="<?php echo e(url('/events')); ?>" class="btn btn-unsolemn btn-action read-more">VIEW ALL</a>
                    </article>
                </div>
            </div>-->
        </div>
    </section><!-- /.home-info -->

    <section class="sabbi-section section-selected_publication">
        <div class="container">
            <div class="selected_pulication-wrap">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="entry-meta">
                            <h2 class="stage-title">About Research Group</h2>
                            <p class="entry-meta-text">
                                <?php echo html_entity_decode($setting->about); ?>

                            </p>
                        </div>
                    </div>
                    <aside class="col-sm-8">
                        <div class="paper_cut">
                            <h2 class="stage-title" style="font-size: 20px; margin-top: -10px">Events</h2>

                            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                                <div class="pub-item with-icon">
                                    <div class="elem-wrapper">
                                        <i class="ion-ios-paper-outline"></i>
                                    </div>
                                    <div class="content-wrapper">
                                        <div class="slc_des">
                                            <div class="authr"><?php echo e($event->title); ?></div>
                                        </div>
                                        <h3 class="title mb_0"><?php echo e(substr(strip_tags($post->description) , 0, 100)); ?> ...</h3>
                                        <div>
                                            <span class="date"><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->date_event))->toFormattedDateString()); ?> - <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->end_event))->toFormattedDateString()); ?></span>
                                        </div>
                                        <div class="description">
                                            <a class="btn btn-info" href="<?php echo e(url('/event')); ?>/?slug=<?php echo e($event->slug); ?>" ><i class="ion-ios-browsers-outline"></i>View</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?> 
                        </div><!-- /.paper_cut -->
                    </aside>
                </div>
            </div><!-- /.selected_pulication-wrap -->
        </div>
    </section><!-- /.section-selected_publication -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>