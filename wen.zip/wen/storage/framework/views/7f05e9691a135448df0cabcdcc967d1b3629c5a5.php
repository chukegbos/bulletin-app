<?php $__env->startSection('pageTitle', 'The Board'); ?>
<?php $__env->startSection('content'); ?>
 <div class="breadcrumb-wrap">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h4>The Board</h4>
            </div>
        </div>
    </div>
</div>
<div class="divide60"></div>
<div class="container">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $board1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 margin20">
                <div class="team-wrap">
                    <?php if(isset($board->image)): ?>
                        <img class="img-responsive"src="<?php echo e(asset('storage')); ?>/<?php echo e($board->image); ?>"  style="height:200px; width:300px">
                    <?php else: ?>
                        <img class="img-responsive" src="{ asset('live/images/avatar.png') }}"  style="height:200px; width:300px">
                    <?php endif; ?>
                    <img src="img/team-1.jpg" class="img-responsive" alt="">
                    <h4><?php echo e($board->name); ?></h4>
                    <span><?php echo e($board->post); ?></span>
                </div><!--team-wrap-->
            </div><!--team col-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
        
    </div><!--features-box container end-->
    <div class="divide50"></div>

</div><!--services container--> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>