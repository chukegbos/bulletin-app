<?php $__env->startSection('pageTitle', 'Edit Post'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
   <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-solid">
            <div class="box-header">
              <h3 class="box-title">Edit Post</h3>
            </div><!-- /.box-header -->

            <div class="box-body">
              <?php if(isset($status)): ?>
                <div class="alert alert-success alert-dismissable" style="margin:20px">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h4>  <i class="icon fa fa-check"></i> Success!</h4>
                    <?php echo e($status); ?>

                </div>
              <?php endif; ?>
              
              <form role="form" enctype="multipart/form-data" action="<?php echo e(url('admin/editpost')); ?>/<?php echo e($post->id); ?>" method="post" >
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('PUT')); ?>

                  <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-12">
                    
                        <div class="form-group">
                            <label for="disabledSelect">Enter Title</label>
                            <input class="form-control" type="text"  name="title" value="<?php echo e($post->title); ?>" Required=""/>
                          
                        </div>

                        <div class="form-group">
                            <label for="your-label" class="form-label">Enter Content</label>
                            <textarea  class="form-control" id="editor1" rows="50" cols="110" name="description">
                              <?php echo e($post->description); ?>

                            </textarea>
                            <script>
                                // Replace the <textarea id="editor1"> with a CKEditor
                                // instance, using default configuration.
                                CKEDITOR.replace( 'editor1' );
                            </script>
                        </div>  
                    </div>

                    <div class="col-md-3 col-sm-3 col-xs-12" style="border: 1px solid grey;margin-right:2px"> 
                      <div style="margin-top:10px; margin-right:10px">                                                                           
                          <input type="hidden" name="author" value="<?php echo e(Auth::user()->name); ?>">
                          <button type="submit" class="btn btn-primary">Publish</button>
                          <div class="form-group" style="margin-bottom:10px; margin-top:10px">
                              <fieldset>
                                  <label>Category</label>
                                  <div style="border: 1px solid grey; height: 20em; overflow-y: auto; white-space: nowrap; padding:5px">
                                      <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                      <div class="c-inputs-stacked">
                                        <?php if(in_array($category->title, $exploded)): ?> 
                                          <input checked type="checkbox" id="checkbox_<?php echo e($category->title); ?>" name="category[]" value="<?php echo e($category->title); ?>"/>
                                          <label for="checkbox_<?php echo e($category->title); ?>" class="block"> <?php echo e($category->title); ?></label> 
                                        <?php else: ?>
                                          <input type="checkbox" id="checkbox_<?php echo e($category->title); ?>" name="category[]" value="<?php echo e($category->title); ?>"/>
                                          <label for="checkbox_<?php echo e($category->title); ?>" class="block"> <?php echo e($category->title); ?></label> 
                                        <?php endif; ?>

                                        <div style="margin-left:30px"> 
                                          <?php $__empty_2 = true; $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                            <?php if($category->title == $sub->parent): ?>
                                              <?php if(in_array($sub->title, $exploded)): ?> 
                                                <input checked type="checkbox" id="checkbox_<?php echo e($sub->title); ?>" name="category[]" value="<?php echo e($sub->title); ?>"/>
                                                <label for="checkbox_<?php echo e($sub->title); ?>" class="block"> <?php echo e($sub->title); ?></label> 
                                              <?php else: ?>
                                                <input type="checkbox" id="checkbox_<?php echo e($sub->title); ?>" name="category[]" value="<?php echo e($sub->title); ?>"/>
                                                <label for="checkbox_<?php echo e($sub->title); ?>" class="block"> <?php echo e($sub->title); ?></label> 
                                              <?php endif; ?>
                                            <?php endif; ?>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                          <?php endif; ?>
                                        </div>  
                                      </div>

                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        No Category Found.
                                      <?php endif; ?>
                                  </div>                                    
                              </fieldset> 
                          </div> 

                          <!--<div class="form-group">
                            
                              <label>Add Tag</label>
                              <select name="tags[]"  class="form-control select2 w-p100" multiple="multiple" data-placeholder="Select tags">
                              
                                <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($tag->title); ?>"><?php echo e($tag->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                              </select>
                          </div>-->
                          <div class="form-group">
                            <label>Add Tag (Separate Tags With Comma)</label>
                            <input class="form-control" value="<?php echo e($post->tag); ?>" type="text"  name="tag"/>
                          
                          </div>

                          <div class="form-group">
                            <div class="c-inputs-stacked">                           
                              <input type="checkbox" id="checkbox_comment_status" checked name="comment_status" value="open"/>
                              <label for="checkbox_comment_status" class="block"> Enable Comment</label> 
                            </div>
                          </div>

                          <div class="form-group">
                              <label for="name" class="form-label">Add Featured Images</label>
                              <div class="input-group image-preview">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-default image-preview-clear" style="display:none;">
                                        <span class="glyphicon glyphicon-remove"></span> Clear
                                    </button>
                                    <div class="btn btn-default image-preview-input">
                                        <span class="glyphicon glyphicon-folder-open"></span>
                                        <span class="image-preview-input-title">Browse</span>
                                        <input type="file" accept="image/png, image/jpeg, image/gif" name="featured_image"/>
                                        
                                    </div>
                                   
                                </span>
                              </div>
                          </div>  
                       </div>                                    
                    </div> 
                  </div>
              </form>
             
            </div>
          </div><!-- /.box -->
        </div>       
      </div>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<script>

function myFunction() {
    var x = document.getElementById("mySelect");
    var option = document.createElement("option");
    x.add(option);
}


$(key).on("keyup", '.tagsinput', function (e) {
    if (e.keyCode == 188) { // KeyCode For comma is 188
        myFunction();
    }
});


$(document).ready(function() {
    $('.js-example-basic-multiple').select2();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>