<?php $__env->startSection('pageTitle', 'Edit Event'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
   <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-solid">
            <div class="box-header">
              <h3 class="box-title">Edit Event</h3>
            </div><!-- /.box-header -->

            <div class="box-body">
              <?php if(isset($status)): ?>
                <div class="alert alert-success alert-dismissable" style="margin:20px">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h4>  <i class="icon fa fa-check"></i> Success!</h4>
                    <?php echo e($status); ?>

                </div>
              <?php endif; ?>
              
              <form role="form" enctype="multipart/form-data" action="<?php echo e(url('admin/editevent')); ?>/<?php echo e($event->id); ?>" method="post" >
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('PUT')); ?>

                  <div class="row">
                    <div class="col-md-8 col-sm-8 col-xs-12">
                    
                        <div class="form-group">
                            <label for="disabledSelect">Enter Occasion Title</label>
                            <input class="form-control" type="text"  name="title" id="myInput" value="<?php echo e($event->title); ?>"  Required=""/>
                          
                        </div>

                        <div class="form-group">
                            <label for="your-label" class="form-label">Enter Content</label>
                            <textarea  class="form-control" id="editor1" rows="50" cols="110" name="description"><?php echo e($event->description); ?>

                            </textarea>
                            <script>
                                // Replace the <textarea id="editor1"> with a CKEditor
                                // instance, using default configuration.
                                CKEDITOR.replace( 'editor1' );
                            </script>
                        </div>  
                    </div>

                    <div class="col-md-3 col-sm-3 col-xs-12"> 
                      <div style="margin-top:10px; margin-right:5px">                                                                           
                                                 
                          <div class="form-group">
                            <label>Start Date of Ocassion</label>
                            <input class="form-control" type="date" value="<?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->date_event))->format('Y-m-d')); ?>"  Required name="date_event"/>                          
                          </div>

                          <div class="form-group">
                            <label>End Date of Occasion</label>
                            <input class="form-control" type="date" value="<?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->end_event))->format('Y-m-d')); ?>"  name="end_event"/>                          
                          </div>

                          <div class="form-group">
                            <label>Venue of Occation</label>
                            <textarea  class="form-control" name="venue" Required><?php echo e($event->venue); ?>  </textarea>                       
                          </div>

                          <div class="form-group">
                            <label>Type of Occasion</label>
                              <select class="form-control" name="type" Required>
                                <option <?php echo e($event->type == "Event" ? 'selected' : ''); ?> value="Event">Event</option>
                                <option <?php echo e($event->type == "Conference" ? 'selected' : ''); ?> Value="Conference">Conference</option>
                              </select>                 
                          </div>
                          <div class="form-group">
                            <label>Add Image</label>
                            <input type="hidden"  value="<?php echo e($event->featured_image); ?>" name="image">
                             <input class="form-control" type="file"  name="featured_image"/>                          
                          </div>
                         
                       </div>                                    
                    </div> 
                  </div>
                  <button type="submit" name="publish" value="Published" class="btn btn-primary">Publish</button>
              </form>
             
            </div>
          </div><!-- /.box -->
        </div>       
      </div>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>