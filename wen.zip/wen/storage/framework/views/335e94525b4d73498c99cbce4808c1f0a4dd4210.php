<?php $__env->startSection('pageTitle', 'Sliders'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <span style="font-size:20px">All Sliders</span> 
      <!-- <a class="btn btn-primary pull-right"  href="<?php echo e(url('/admin/addslider')); ?>">Add slider</a>-->
     <a class="btn btn-primary pull-right" href="" data-toggle="modal" data-target="#addslidermodal" >Add Slider</a>
    </section>


      <!-- Main content -->
      <!-- Main content -->
    <section class="content">
      <?php if(isset($status)): ?>
          <div class="alert alert-success alert-dismissable" style="margin:20px">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4>  <i class="icon fa fa-check"></i> Success!</h4>
              <?php echo e($status); ?>

          </div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
          <div class="alert alert-danger alert-dismissable" style="margin:20px">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4>  <i class="icon fa fa-times"></i> Error!</h4>
              <?php echo e($error); ?>

          </div>
        <?php endif; ?>
      <div class="row">
        <div class="col-12">
          <div class="box box-solid">
            <div class="box-body">
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="example2" class="table table-bordered table-hover">
                      <thead>
                        <tr>
                          <th>Title</th>
                          <th>Short Descripton</th>
                          <th>Image</th>
                          <!--<th>Edit</th>-->
                          <th>Delete</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><?php echo e($slider->title); ?></td>
                          <th><?php echo e(substr(strip_tags($slider->description) , 0, 90)); ?> ...</th>
                          <th><img class="img-thumbnail" src="<?php echo e(asset('storage')); ?>/<?php echo e($slider->image); ?>" width="70px"></th>
                          <!--<a href=""><i class="fa fa-edit btn btn-info"></i> </a>
                           <td> 
                            <a 
                              class="open-AddBookDialog btn btn-info" 
                              href="#" 
                              data-toggle="modal" 
                              data-target="#editmodal" 

                              data-id="<?php echo e($slider->id); ?>"
                              data-title="<?php echo e($slider->title); ?>"
                              data-description="<?php echo e(strip_tags($slider->description)); ?>">
                              
                              <i class="fa fa-edit"></i> 
                              </a>
                          </td>-->
                          <td>
                            <form action="<?php echo e(url('/admin/destroyslider')); ?>/<?php echo e($slider->id); ?>" method="POST">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(Method_field('DELETE')); ?>

                               <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                            </form>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                      </tbody>                     
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>        
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <div class="modal fade" id="addslidermodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
      <div class="modal-dialog" style="background:white">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"> Add Slider</h4>
            </div>
            <div class="modal-body">
              <form method="post" class="profile-wrapper" enctype="multipart/form-data" action="<?php echo e(url('admin/slider')); ?>" >
                 <?php echo e(csrf_field()); ?>

                  
                  <div class="form-group">
                      <label for="fname">Title</label>                     
                      <input class="form-control" type="text" name="title" required autofocus>
                  </div> 

                  <div class="form-group">
                      <label for="fname">Short Description</label>
                      <textarea  class="form-control"  cols="50" name="description">
                      </textarea>
                  </div>

                  <div class="form-group">
                      <label for="fname">Featured Image</label>
                      <input class="form-control" type="file" name="image" required autofocus>  
                  </div>   

                  <button type="submit" class="btn btn-success pull-right">Add <i class="fa fa-save"></i></button>                              
              </form>
            </div>
            
            <div class="modal-footer">
             
            </div>
          </div><!-- /.modal-content -->                     
      </div>
    </div>

    <div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
      <div class="modal-dialog" style="background:white">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"> Edit slider</h4>
            </div>
            <div class="modal-body">
              <form method="post" class="profile-wrapper" enctype="multipart/form-data" action="<?php echo e(url('admin/editslider')); ?>" >
                 <?php echo e(csrf_field()); ?>

                 <?php echo e(method_field('PUT')); ?>

                  <span id="mainname"></span>
                  <div class="form-group">
                      <label for="fname">Title</label>   
                      <input type="hidden" name="id" id="mainid">                   
                      <input class="form-control" type="text" name="name" id="mainname" Required>                     
                  </div>

                  
                  <div class="form-group">
                      <label for="fname">Description</label>  
                      <textarea class="form-control" id="maincode" name="description" required autofocus></textarea>                   
                  </div>

                  <div class="form-group">
                      <label for="fname">Featured Image</label>

                      <input class="form-control" type="file" name="image" required autofocus>  
                  </div>  
                  <button type="submit" class="btn btn-success pull-right">Save <i class="fa fa-save"></i></button>                              
              </form>
            </div>
            
            <div class="modal-footer">
             
            </div>
          </div><!-- /.modal-content -->                     
      </div>
    </div>
      <script>
      //result modal
      $(document).on("click", ".open-AddBookDialog", function () {
         var facultyId = $(this).data('id');
         var facultyname = $(this).data('title');
         var facultycode = $(this).data('description');

         $(".modal-body #mainid").val( facultyId );
         $(".modal-body #mainname").val( facultyname );
         $(".modal-body #maincode").val( facultycode );
        $('#editmodal').modal('show');


      });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>