<?php if(isset($cat)): ?>
  <?php $__env->startSection('pageTitle', $cat); ?>
<?php else: ?>
  <?php $__env->startSection('pageTitle', 'Publications'); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
<div class="auth-breadcrumb-wrap" style="margin-top: 115px">
  <div class="container">
    <ol class="sabbi-breadcrumb breadcrumb">
      <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
      <?php if(isset($cat)): ?>
        <li class="active"><?php echo e($cat); ?></li>
      <?php else: ?>
        <li class="active">Publications</li>
      <?php endif; ?>
    </ol>
  </div>
</div>
<main class="sabbi-page-wrap">
  <div class="container">
    <section class="sabbi-section stage-samevide mb_0">
      <div class="row">
        <div class="col-sm-12">
          <div class="page_piky-title" style="padding: 10px">
            <?php if(isset($cat)): ?>
              <h2 class="page-title font-md lil-line"><?php echo e($cat); ?></h2>
            <?php else: ?>
              <h2 class="page-title font-md lil-line">Publications</h2>
            <?php endif; ?>
            
          </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>      
          <div class="col-md-4 col-sm-6">
            <div class="portfolio-item" style="height: 360px;">
              <img src="<?php echo e(asset('storage')); ?>/<?php echo e($post->featured_image); ?>" alt="" class="img-responsive portfolio-image" style="height: 200px; width: 300px; float: none;">
         
                <h2 class="meta-title ht-5"><?php echo e($post->title); ?></h2>
                <p class="meta-text"><?php echo e(substr(strip_tags($post->description) , 0, 90)); ?> ...</p>
                <a href="<?php echo e(url('/')); ?>/<?php echo e($post->slug); ?>" class="btn btn-info btn-xs pull-left">Read More</a> 
                <a href="<?php echo e(asset('storage')); ?>/<?php echo e($post->pdf); ?>" class="btn btn-success btn-xs pull-right">Download PDF</a>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <h2>No news found, check back later</h2>
        <?php endif; ?>
        <div class="col-md-12">
          <ul class="pagination theme-colored">
            <?php echo e($posts->links()); ?>

          </ul>
        </div>
      </div>
    </section>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>