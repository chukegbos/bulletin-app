<?php $__env->startSection('pageTitle', 'Events'); ?>
<?php $__env->startSection('content'); ?>

    <section class="inner-header divider parallax layer-overlay overlay-dark-5">
      <div class="container">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white"><?php echo e($event->title); ?></h3>
            </div>
          </div>
        </div>
      </div>
    </section>

   <section>
      <div class="container">
        <div class="row">
          <div class="col-md-8">
             <img alt="<?php echo e($event->title); ?>" src="<?php echo e(asset('storage')); ?>/<?php echo e($event->featured_image); ?>" style="width:700px; height:500px">
          </div>
          <div class="col-md-4 mt-60">
            <ul>
              <li>
                <h4><?php echo e($event->type); ?>:</h4>
                <p><?php echo e($event->title); ?></p>
              </li>
              <li>
                <h4>Theme:</h4>
                <p><?php echo e($event->theme); ?></p>
              </li>
             
              <li>
                <h4>Location:</h4>
                <p><?php echo e($event->venue); ?></p>
              </li>
              <li>
                <h4>Start Date:</h4>
                <p><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->date_event))->toFormattedDateString()); ?></p>
              </li>
              <li>
                <h4>End Date:</h4>
                <p><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->end_event))->toFormattedDateString()); ?></p>
              </li>
             
              <li>
                  
                  <div class="sharethis-inline-share-buttons"></div>
                  
                
              </li>
            </ul>
          </div>
        </div>
        <div class="row mt-60">
          <div class="col-md-12">
            <h3 class="mt-0 text-theme-colored"><?php echo e(ucfirst($event->type)); ?> Description</h3>
            <p style="text-align:justify"><?php echo e(strip_tags($event->description)); ?></p>
          </div>
          
        </div>
       
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>