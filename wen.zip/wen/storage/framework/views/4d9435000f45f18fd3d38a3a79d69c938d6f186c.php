<?php $__env->startSection('pageTitle', 'News'); ?>
<?php $__env->startSection('content'); ?>
<div class="breadcrumb-wrap">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <?php if(isset($q)): ?>
                    <h4><?php echo e($q); ?></h4>
                <?php else: ?>
                    <h4>News and Events</h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><!--breadcrumbs-->
<div class="divide80"></div>
        
<div class="container">
    <div class="row">
         <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3">
                <div class="blog-post">
                    <a href="#">
                        <div class="item-img-wrap">
                            <img src="<?php echo e(asset('storage')); ?>/<?php echo e($post->featured_image); ?>" class="img-responsive" alt="workimg">
                            <div class="item-img-overlay">
                                <span></span>
                            </div>
                        </div>                       
                    </a><!--work link-->
                    <ul class="list-inline post-detail">
                        <li>by <a href="#"><?php echo e($post->author); ?></a></li>
                        <li><i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($post->created_at))->toFormattedDateString()); ?></li>
                    </ul>
                    <h2 style="font-size:15px;"><a href="<?php echo e(url('/')); ?>/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h3>
                    <p style="text-align:justify"><?php echo e(substr(strip_tags($post->description) , 0, 120)); ?></p>
                    <p><a href="<?php echo e(url('/')); ?>/<?php echo e($post->slug); ?>" class="btn btn-theme-dark">Read More...</a></p>
                </div><!--blog post-->                   
            </div><!--col 5-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h2>Nothing found, check back later</h2>
        <?php endif; ?>
    </div><!--row for blog post-->
    <div class="row">
        <div class="col-md-10">
              <ul class="pager">
                <?php echo e($posts->links()); ?>

            </ul><!--pager-->
        </div>
    </div>
</div><!--blog full main container-->
<div class="divide60"></div>


 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>