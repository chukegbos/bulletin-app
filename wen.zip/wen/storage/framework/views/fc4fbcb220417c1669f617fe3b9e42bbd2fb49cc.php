<?php $__env->startSection('pageTitle', $post->title); ?>
<?php $__env->startSection('content'); ?>
<div class="breadcrumb-wrap">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h4><?php echo e($post->title); ?></h4>
            </div>
        </div>
    </div>
</div><!--breadcrumbs-->
<div class="divide80"></div>
        
<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="blog-post">
                    <div>
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($post->featured_image); ?>" style="height: 350px;width: 800px;" class="img-responsive" alt="workimg">
                  
                    </div>                       
                <ul class="list-inline post-detail">
                    <li>by <a href="#"><?php echo e($post->author); ?></a></li>
                    <li><i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($post->created_at))->toFormattedDateString()); ?></li>
                    <li><i class="fa fa-tag"></i> <a href="#"><?php echo e($post->tag); ?></a></li>
                    <li><i class="fa fa-comment"></i> <a href="#">6 Comments</a></li>
                </ul>
                <h2><?php echo e($post->title); ?></h2>
                
                <p class="dropcap">
                     <?php echo e(strip_tags($post->description)); ?>

                 </p> 
            </div>
        </div><!--col-->
        <div class="col-md-3 col-md-offset-1">
            <div class="sidebar-box margin40">
                <h4>Search</h4>
                <form role="form" class="search-widget">
                    <input type="text" class="form-control">
                    <i class="fa fa-search"></i>
                </form>
            </div>

            <div class="sidebar-box margin40">
                <h4>Our Product</h4>
                <ul class="list-unstyled cat-list">
                    <?php $__empty_1 = true; $__currentLoopData = $product1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li> <a href="<?php echo e(url('/service')); ?>/?service=<?php echo e($product->slug); ?>"><?php echo e($product->name); ?></a> <i class="fa fa-angle-right"></i></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>
            </div><!--sidebar-box-->
            <div class="sidebar-box margin40">
                <h4>Popular Post</h4>
               <ul class="list-unstyled popular-post">
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li>
                            <div class="popular-img">
                                <a href="<?php echo e(url('/')); ?>/<?php echo e($pro->slug); ?>"> <img src="<?php echo e(asset('storage')); ?>/<?php echo e($pro->featured_image); ?>" class="img-responsive" alt=""></a>
                            </div>
                            <div class="popular-desc">
                                <h5> <a href="<?php echo e(url('/')); ?>/<?php echo e($pro->slug); ?>"><?php echo e($pro->title); ?></a></h5>
                                <h6><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($pro->created_at))->toFormattedDateString()); ?></h6>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                </ul>
            </div><!--sidebar-box-->
         
        </div><!--sidebar-col-->
    </div><!--row for blog post-->
</div><!--blog full main container-->
<div class="divide60"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>