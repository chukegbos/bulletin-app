<?php $__env->startSection('pageTitle', 'Gallery'); ?>
<?php $__env->startSection('content'); ?>
<div class="breadcrumb-wrap">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <?php if(isset($q)): ?>
                    <h4><?php echo e($q); ?></h4>
                <?php else: ?>
                    <h4>Gallery</h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><!--breadcrumbs-->
<div class="divide80"></div>       
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div id="grid" class="row">
                <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="mix col-sm-3 page1 page4 margin30">
                        <div class="item-img-wrap ">
                            <img src="<?php echo e(asset('storage')); ?>/<?php echo e($gallery->image); ?>" class="img-responsive" alt="Ukpor MFB">
                            <div class="item-img-overlay">
                                <a href="<?php echo e(asset('storage')); ?>/<?php echo e($gallery->image); ?>">
                                    <span><?php echo e($gallery->name); ?></span>
                                </a>
                            </div>
                        </div> 
                        <p><?php echo e($gallery->name); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>                                                         
            </div><!--#grid-->
        </div>
    </div>

    <div class="row gallery-bottom">
        <div class="col-sm-6">
            <ul class="pagination">
                <?php echo e($galleries->links()); ?>

            </ul>
        </div>
    </div>
</div><!--gallery container-->
<div class="divide60"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>