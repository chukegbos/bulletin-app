<?php $__env->startSection('pageTitle', 'Service'); ?>
<?php $__env->startSection('content'); ?>
 <div class="breadcrumb-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <h4><?php echo e($services->name); ?></h4>
                    </div>
                </div>
            </div>
        </div><!--breadcrumbs-->
        <div class="divide80"></div>
        <div class="container">
            <div class="row">
                <?php if(isset($services->image)): ?>
                    <div class="col-md-6 margin20">
                        <h3 class="heading"><?php echo e($services->name); ?></h3>
                        <p style="text-align:justify">
                          <?php echo e(strip_tags($services->description)); ?>

                        </p>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($services->image); ?>" class="img-responsive" alt="">
                    </div>
                <?php else: ?>
                    <div class="col-md-12 margin20">
                        <h3 class="heading"><?php echo e($services->name); ?></h3>
                        <p style="text-align:justify">
                          <?php echo e(strip_tags($services->description)); ?>

                        </p>
                    </div>
                <?php endif; ?>
            </div><!--about intro-->
        </div>

<div class="divide60"></div>
<div class="container">
    <div class="row special-feature">
        <?php $__empty_1 = true; $__currentLoopData = $services1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 col-sm-6 margin20">
                <a href="<?php echo e(url('/service')); ?>/?service=<?php echo e($service->slug); ?>"><div class="s-feature-box text-center wow animated fadeIn" data-wow-duration="700ms" data-wow-delay="200ms">
                    <div class="mask-top">
                        <!-- Icon -->
                        <img src="<?php echo e(asset('storage')); ?>/<?php echo e($service->image); ?>" height="100px" width="250px">
                        <!-- Title -->
                        <h4><?php echo e($service->name); ?></h4>
                    </div>
                    <div class="mask-bottom">
                        <!-- Icon -->
                        <i class="pe-7s-like2"></i>
                        <!-- Title -->
                        <h4><?php echo e($service->name); ?></h4>
                        <!-- Text -->
                        <p><?php echo e(substr(strip_tags($service->description) , 0, 150)); ?> ...</p>
                    </div>
                </div></a>
            </div><!--services col-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
        
    </div><!--features-box container end-->
    <div class="divide50"></div>

</div><!--services container-->

<div class="divide70"></div>
<div class="assan-features">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="center-heading">
                    <h2 style="color:#FC6F4D">Awesome <strong>Products</strong></h2>
                    <span class="center-line"></span>
                </div>
            </div>                   
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $product1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4 col-sm-6 margin20 special-feature">
                    <div class="services-box wow animated fadeIn" data-wow-duration="700ms" data-wow-delay="100ms">
                        <div class="services-box-icon">
                            <img src="<?php echo e(asset('live/images/logo_2.png')); ?>" height="40px" width="40px" alt="ASSAN">
                        </div><!--services icon-->
                        <div class="services-box-info"style="text-align:justify">
                            <h4 style="color:#68AD6E; font-size:14px"><?php echo e($product->name); ?></h4>
                            <p ><?php echo e(substr(strip_tags($product->description) , 0, 120)); ?> ...</p>
                            <a class="btn btn-success pull-left"  href="<?php echo e(url('/service')); ?>/?service=<?php echo e($product->slug); ?>"> View</a>
                        </div>
                    </div><!--services box-->
                </div><!--services col-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div><!--services row-->
    </div>
</div><!--assan features-->
<div class="divide40"></div>

 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>