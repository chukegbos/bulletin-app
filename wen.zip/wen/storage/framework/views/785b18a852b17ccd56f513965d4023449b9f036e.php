<?php $__env->startSection('pageTitle', 'Contact us'); ?>
<?php $__env->startSection('content'); ?>
 <div class="breadcrumb-wrap">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h4>Contact Us</h4>
            </div>
        </div>
    </div>
</div>

<div class="divide60"></div>
<div class="container">
    <div class="row">

        <div class="col-md-4 col-sm-4 margin30">
            <h3 class="heading">Main Branch</h3>
            <ul class="list-unstyled contact contact-info">
                <li><p><strong><i class="fa fa-map-marker"></i> Address:</strong> <?php echo e($setting->address); ?></p></li> 
                <li><p><strong><i class="fa fa-envelope"></i> Mail Us:</strong> <a href="mailto: <?php echo e($setting->email); ?>"><?php echo e($setting->email); ?></a></p></li>
                <li> <p><strong><i class="fa fa-phone"></i> Phone:</strong> <?php echo e($setting->phone); ?></p></li>
            </ul>
            <div class="divide40"></div>     
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $branch1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 col-sm-4 margin30">
            <h3 class="heading"><?php echo e($branch->name); ?> Branch</h3>
            <ul class="list-unstyled contact contact-info">
                 <li><p><strong><i class="fa fa-map-marker"></i> Address:</strong> <?php echo e($branch->address); ?></p></li> 
                <li><p><strong><i class="fa fa-envelope"></i> Mail Us:</strong> <a href="mailto: <?php echo e($branch->email); ?>"><?php echo e($branch->email); ?></a></p></li>
                <li> <p><strong><i class="fa fa-phone"></i> Phone:</strong> <?php echo e($branch->phone); ?></p></li>
            </ul><div class="divide40"></div>                      
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>