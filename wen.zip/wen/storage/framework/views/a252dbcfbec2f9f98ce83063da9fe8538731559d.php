<?php $__env->startSection('pageTitle', 'All '.$type.'s'); ?>
<?php $__env->startSection('content'); ?>

    <section class="inner-header divider parallax layer-overlay overlay-dark-5">
      <div class="container">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">All <?php echo e($type); ?>s</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container pb-0">
        <div class="section-content">
          <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>              
              <div class="col-sm-12 col-md-12 col-lg-12 mb-50">
                <div class="schedule-box maxwidth500 clearfix mb-30" data-bg-img="images/pattern/p26.png">
                  <div class="col-md-5">
                    <div class="thumb">
                      <img class="img-fullwidth" alt="" src="<?php echo e(asset('storage')); ?>/<?php echo e($event->featured_image); ?>" style="width:200px; height:200px">
                    </div>
                  </div>
                  <div class="col-md-7">
                    <div class="schedule-details clearfix p-15 pt-30">
                      <div class="text-center pull-left flip bg-theme-colored p-10 pt-5 pb-5 mr-10">
                        <ul>
                          <li class="font-24 text-white font-weight-600 border-bottom "> <?php echo e($event->date_event->day); ?>th</li>
                          <li class="font-18 text-white text-uppercase"><?php echo e($event->date_event->month); ?></li>
                        </ul>
                      </div>
                      <h3 class="title mt-0"><a href="<?php echo e(url('/event')); ?>/?slug=<?php echo e($event->slug); ?>"><?php echo e($event->title); ?></a></h3>
                      <ul class="list-inline text-gray">
                        <li><i class="fa fa-calendar mr-5"></i> Starts : <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->date_event))->toFormattedDateString()); ?></li>
                        <br><li><i class="fa fa-calendar mr-5"></i> Ends : <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($event->end_event))->toFormattedDateString()); ?></li>
                        <br><li><i class="fa fa-map-marker mr-5"></i> <?php echo e($event->venue); ?></li>
                      </ul>
                      <div class="clearfix"></div>
                      <div class="mt-10">
                       <a href="<?php echo e(url('/event')); ?>/?slug=<?php echo e($event->slug); ?>" class="btn btn-default btn-theme-colored mt-10 font-16 btn-sm pull-right">View</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?> 
          </div>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>