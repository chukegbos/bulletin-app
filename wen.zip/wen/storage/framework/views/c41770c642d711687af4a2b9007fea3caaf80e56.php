<?php $__env->startSection('pageTitle', 'Gallery'); ?>
<?php $__env->startSection('content'); ?>
<div class="auth-breadcrumb-wrap" style="margin-top: 115px">
  <div class="container">
    <ol class="sabbi-breadcrumb breadcrumb">
      <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
      <li class="active">Gallery</li>
    </ol>
  </div>
</div>
<main class="sabbi-page-wrap">
  <div class="container">
    <section class="sabbi-section stage-samevide mb_0">
      <div class="row">
        <div class="col-sm-12">
          <div class="page_piky-title" style="padding: 10px">
            <h2 class="page-title font-md lil-line">Gallery</h2>
          </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-md-4 col-sm-6">
            <div class="portfolio-item">
              <a href="<?php echo e(asset('storage')); ?>/<?php echo e($gallery->image); ?>"><img  class="img-responsive portfolio-image" src="<?php echo e(asset('storage')); ?>/<?php echo e($gallery->image); ?>" style="height:250px"></a>
              <div class="overlay-shade"></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p><h2>No Photo Found!</h2></p><br>
        <?php endif; ?>

        <div class="col-md-12">
          <ul class="pagination theme-colored">
            <?php echo e($galleries->links()); ?>

          </ul>
        </div>
      </div>
    </section>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>