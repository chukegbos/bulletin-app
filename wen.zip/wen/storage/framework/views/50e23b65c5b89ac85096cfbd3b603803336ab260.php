<?php $__env->startSection('pageTitle', 'Tags'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
   <section class="content">
      <div class="row">
        <div class="col-md-4">
          <div class="box box-solid">
            <div class="box-header">
              <h3 class="box-title">Add Tag</h3>
            </div><!-- /.box-header -->

            <div class="box-body">
              <?php if(isset($status)): ?>
                <div class="alert alert-success alert-dismissable" style="margin:20px">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h4>  <i class="icon fa fa-check"></i> Success!</h4>
                    <?php echo e($status); ?>

                </div>
              <?php endif; ?>
              <form role="form" action="<?php echo e(url('/admin/tag')); ?>" method="POST" >
                  <?php echo e(csrf_field()); ?>

                  <!-- text input -->
                  <div class="form-group">
                      <label>Tag name</label>
                      <input type="text" class="form-control" name="title" Required/>
                       <?php if($errors->has('title')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('title')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <!-- textarea -->
                    <div class="form-group">
                      <label>Brief Description</label>
                      <textarea class="form-control" rows="3" name="description"></textarea>
                       <?php if($errors->has('description')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                  <div class="form-group">
                      <input type="submit" value="Add" class="btn btn-success">
                  </div>
              </form>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </div>
        <div class="col-md-8">
          <div class="box">
            <div class="box-body">
              <div class="table-responsive">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                      <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Slug</th>
                        <th>Count</th>
                        <th>Action</th>
                        <th>Delete</th>

                      </tr>
                    </thead>
                  <tbody>

                  <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>

                      <td><?php echo e($tag->title); ?></td>
                      <td><?php echo e($tag->description); ?></td>
                      <td><?php echo e($tag->slug); ?></td>
                      <td><?php echo e($tag->count); ?></td>
                      <td><a target="_blank" class="btn btn-primary btn-sm" href="">View</a> <!--<a href="<?php echo e(url('edittag')); ?>/<?php echo e($tag->id); ?>"><i class="fa fa-edit btn btn-info btn-sm">Edit</i></a>--></td>
                      <td>
                        <form action="<?php echo e(url('/admin/deletetag')); ?>/<?php echo e($tag->id); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(Method_field('DELETE')); ?>

                          <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <?php endif; ?>
                </table>
              </div>
            </div>
          </div><!-- /.box -->
        </div>
      </div>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>