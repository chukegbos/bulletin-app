<?php $__env->startSection('pageTitle', 'Admin Home'); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Welcome to <?php echo e($setting->sitename); ?> Dashboard
      </h1>
    </section> 

    <section class="content">
      <div class="row">
        <div class="col-lg-4 col-12">
          <div class="box box-solid bg-black">
            <div class="box-header with-border">
              <h4 class="box-title">About Us</h4>
            </div>
            <div class="box-body p-0">
              <div class="media-list media-list-hover media-list-divided">
                <p class="media media-single p-10">
                  <b>Our Vision</b>
                  <span class="title"><?php echo e($setting->vision); ?></span>
                </p>
                <hr>

                <p class="media media-single p-10">
                  <b>Our Mission</b>
                  <span class="title"><?php echo e($setting->mission); ?></span>
                </p>
                <hr>
                <h5 style="margin-left:5px"><b><u style="margin-left: 15px;">Products</u></b></h5>
                <?php $__empty_1 = true; $__currentLoopData = $product1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <p class="media media-single p-10">
                    <span class="title">
                      <?php echo e($product->name); ?><br>
                    </span>
                </p>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <?php endif; ?>
                

              </div>
            </div>
          </div>        
        </div>

        <div class="col-lg-8 col-12">
          <div class="row">
            <div class="col-md-12 col-12">            
              <div class="box box-solid">
                <div class="box-header with-border">
                  <h4 class="box-title">Services</h4>
                </div>
                <div class="box-body">
                  <div class="row">
                    <div class="col-12">
                      <div class="table-responsive">
                        <table id="example2" class="table table-bordered table-hover">
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Descripton</th>
                              <th>Featured Image</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $services1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                              <td><?php echo e($service->name); ?></td>
                              <th><?php echo e(substr(strip_tags($service->description) , 0, 90)); ?> ...</th>
                              <th><img class="img-thumbnail" src="<?php echo e(asset('storage')); ?>/<?php echo e($service->image); ?>" width="70px"></th>
                              <!--<a href=""><i class="fa fa-edit btn btn-info"></i> </a>-->                       
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                          </tbody>                     
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>