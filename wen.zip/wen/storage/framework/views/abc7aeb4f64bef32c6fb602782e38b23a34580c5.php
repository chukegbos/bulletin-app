<?php $__env->startSection('pageTitle', 'All Posts'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
   <section class="content">
      <div class="row">
        
        <div class="col-md-12">
          <div class="box-header">
            <h3 class="box-title">All post</h3>
          </div><!-- /.box-header -->

          <div class="box">
            <div class="box-body">
              <div class="table-responsive">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                      <tr>
                        <th>Title</th>
                        <th>Categories</th>
                        <th>Date Published</th>
                        <th>Action</th>
                        <th>Delete</th>

                      </tr>
                    </thead>
                  <tbody>

                  <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($post->title); ?></td>
                      <td><?php echo e($post->category); ?></td>
                      <td><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($post->created_at))->toFormattedDateString()); ?><br><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($post->created_at))->diffForHumans()); ?></td>
                      <td>
                        <a target="_blank" class="btn btn-primary btn-sm" href="">View</a> 
                        <a href="<?php echo e(url('admin/editpost')); ?>/?slug=<?php echo e($post->slug); ?>"><i class="fa fa-edit btn btn-info btn-sm">Edit</i></a></td>
                      <td>
                        <form action="<?php echo e(url('/admin/deletepost')); ?>/<?php echo e($post->id); ?>" method="POST">
                          <?php echo e(csrf_field()); ?>

                          <?php echo e(Method_field('DELETE')); ?>

                          <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <?php endif; ?>
                </table>
              </div>
            </div>
          </div><!-- /.box -->
        </div>
      </div>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>