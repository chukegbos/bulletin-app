
<?php $__env->startSection('pageTitle', 'Start Ups'); ?>
<?php $__env->startSection('content'); ?>

    <section class="inner-header divider parallax layer-overlay overlay-dark-5">
      <div class="container">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">Our Start Ups</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
<section id="causes" class="bg-silver-light">
  <div class="container">
    <div class="section-title text-center">
      <div class="row">
        <div class="col-md-10 col-md-offset-1">
          <h2 class="text-uppercase line-bottom-center mt-0">Our <span class="text-theme-colored font-weight-600">Start Ups</span></h2>
          <div class="title-icon">
            <i class="flaticon-charity-hand-holding-a-heart"></i>
          </div>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem voluptatem obcaecati! <br>ipsum dolor sit Rem autem voluptatem obcaecati</p>
        </div>
      </div>
    </div>
    <div class="section-content">
      <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-sm-6 col-md-6">
          <div class="causes bg-white border-1px border-bottom-theme-color-1px">
            <div class="col-md-5 col-lg-5 p-0">
              <div class="thumb">
                <img class="img-fullwidth" alt="" src="<?php echo e(asset('storage')); ?>/<?php echo e($product->image); ?>" style="width:180px; height:180px">                   
              </div>
            </div>
            <div class="col-md-7 col-lg-7 p-0">
              <div class="causes clearfix p-20 pt-15">
                <h3 class="mt-0"><a class="text-theme-colored" href="<?php echo e(url('/startups')); ?>/?startup=<?php echo e($product->slug); ?>"><?php echo e(substr(($product->name) , 0, 25)); ?></a></h3>
                <p class="pt-0"><?php echo e(substr(strip_tags($product->description) , 0, 150)); ?> ...</p>
                <p><a href="<?php echo e(url('/startups')); ?>/?startup=<?php echo e($product->slug); ?>" class="btn btn-success"> View</a></p>                  
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
      </div>

      <div class="pagination">
        <?php echo e($products->links()); ?>

      </div>
    </div>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>