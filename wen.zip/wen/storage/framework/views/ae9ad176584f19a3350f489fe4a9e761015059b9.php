
<?php $__env->startSection('pageTitle', 'Contact us'); ?>
<?php $__env->startSection('content'); ?>

    <section class="inner-header divider parallax layer-overlay overlay-dark-5">
      <div class="container">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">Contact Us</h3>
            </div>
          </div>
        </div>
      </div>
    </section>

<section class="divider">
      <div class="container pt-0">
        <div class="row mb-60 bg-deep">
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center pt-60 pb-60 border-right">
              <i class="fa fa-phone font-36 mb-10 text-theme-colored"></i>
              <h4>Call Us</h4>
              <h6 class="text-gray">Phone: <?php echo e($setting->phone); ?></h6>
            </div>
          </div>
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center  pt-60 pb-60 border-right">
              <i class="fa fa-map-marker font-36 mb-10 text-theme-colored"></i>
              <h4>Address</h4>
              <h6 class="text-gray"><?php echo e($setting->address); ?></h6>
            </div>
          </div>
          <div class="col-sm-12 col-md-4">
            <div class="contact-info text-center  pt-60 pb-60">
              <i class="fa fa-envelope font-36 mb-10 text-theme-colored"></i>
              <h4>Email</h4>
              <h6 class="text-gray"><?php echo e($setting->email); ?></h6>
            </div>
          </div>
        </div>


        <div class="row pt-10">
          <div class="col-md-12">
          <h4 class="mt-0 mb-30 line-bottom">Find Our Location</h4>
          <!-- Google Map HTML Codes -->
        <div>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d991.0700354737791!2d7.498824849451355!3d6.486164443701157!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1044a30c6e6b8db7%3A0x57a5fe3638c5267!2sUdoye+St%2C+Trans-Ekulu%2C+Enugu!5e0!3m2!1sen!2sng!4v1537369242598" width="1980" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
        
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.live', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>